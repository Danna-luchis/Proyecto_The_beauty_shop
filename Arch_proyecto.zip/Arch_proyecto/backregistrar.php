<?php

include("conexion.php");

if (isset($_POST['register'])){
    if(
        strlen($_POST['name']) >= 1 &&
        strlen($_POST['email']) >= 1 &&
        strlen($_POST['direction']) >= 1 &&
        strlen($_POST['phone']) >= 1 &&
        strlen($_POST['password']) >= 1
            ) {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $direction = trim($_POST['direction']);
        $phone = trim($_POST['phone']);
        $password = trim($_POST['password']);
        
        $consulta = "INSERT INTO usuarios(nombre,email,direccion,telefono,contraseña)
            VALUES('$name','$email','$direction','$phone','$password')";
        
        $resultado=mysqli_query($conexion,$consulta);
        
        if($resultado){
            ?>
                <center><h2 class="success" >Tu registro se ha completado satisfactoriamente</h2></center>
            <?php
        } else {
            ?>
                <center><h2 class="error" >Ocurrio un error</h2></center>
            <?php
            }
        } else {
        ?>
            <center><h2 class="error" >Llene los campos de registro</h2></center>
        <?php
        }   
    }
?>