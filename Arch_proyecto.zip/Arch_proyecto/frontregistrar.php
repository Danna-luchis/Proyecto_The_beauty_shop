<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body bgcolor="#ffccaa"><img src="images/tinalandia Beauty.png" width="15%" align="right"><br><br><br><br><br><br><br><br><br><br><br><br>
<center><form method="post">
<font color="#9B00FF"><h1>Bienvenido</h1></font>
    <h2><font color="#0068FF">Registrar</h2></font>
    <div class="input-wrapper">
        <input type="text" name="name" placeholder="Nombre">
        <img class="input-icon" src="images/name.svg" alt="">
</div>

<div class="input-wrapper">
        <input type="email" name="email" placeholder="Correo Electronico">
        <img class="input-icon" src="images/name.svg" alt="">
</div>

<div class="input-wrapper">
        <input type="text" name="direction" placeholder="Dirección">
        <img class="input-icon" src="images/name.svg" alt="">
</div>

<div class="input-wrapper">
        <input type="tel" name="phone" placeholder="Telefono">
        <img class="input-icon" src="images/name.svg" alt="">
</div>

<div class="input-wrapper">
        <input type="password" name="password" placeholder="Contraseña">
        <img class="input-icon" src="images/name.svg" alt="">
</div><br>

<input class type="submit" name="register" value="Registrarme">
</form></center><br>

<?php
        include("backregistrar.php");
?>

</body>

<center><a class="btn" href="frontiniciarsesion.php">Iniciar Sesion</a><br><br>
<a class="btn" href="nosotros.php">Nosotros</a><br><br>
<a class="btn" href="principal.php">Pagina Principal</a><br><br>
</center>

</html>