
<?php

include("conexion.php");


$id=$_GET['Id'];
$sql="DELETE FROM productos WHERE idProducto='$id'";

$query= mysqli_query($conexion, $sql);

if($query === TRUE) 
    {
        ?>
            <h2 class="success" >El registro fue ELIMINADO correctamente</h2>
        <?php
    }    
    header("location:/modelo/frontregistros.php"); 
?>

