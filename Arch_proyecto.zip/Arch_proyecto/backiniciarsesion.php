<?php

include("conexion.php");
session_start();

$usuario = $_POST['usuario'];
$clave = $_POST['clave'];

$s = "SELECT COUNT(*) as contar from usuarios WHERE nombre='$usuario' AND contraseña='$clave'";
$consulta = mysqli_query($conexion, $s);
$array=mysqli_fetch_array($consulta);

if ($array['contar']>0){
    header("location:/modelo/frontregistros.php");
    }else{
        ?>
                <center><h2 class="success" >Tu registro se ha completado satisfactoriamente</h2></center>
        <?php
        header("location:/modelo/frontiniciarsesion.php");
    }
?>