<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Iniciar Sesion</title>
</head>
<body bgcolor="#ffccaa"><img src="images/tinalandia Beauty.png" width="15%" align="right"><br><br><br><br><br><br><br><br><br><br><br><br>
            
    <center><font color="#9B00FF"><h1>Bienvenido</h1></font>
    <h2><font color="#0068FF">Iniciar</h2>

    <form action="backiniciarsesion.php" method="POST">
    <input type="text" name="usuario" placeholder="Nombre"><br><br>
    <input type="password" name="clave" placeholder="Contraseña"><br><br><br>

    <button type="submit">ENTRAR </button></center><br>

</form>
</body>

<center><a class="btn" href="frontregistrar.php">Registrar</a><br><br>
<a class="btn" href="nosotros.php">Nosotros</a><br><br>
<a class="btn" href="principal.php">Pagina Principal</a><br><br>
</center>

</html>