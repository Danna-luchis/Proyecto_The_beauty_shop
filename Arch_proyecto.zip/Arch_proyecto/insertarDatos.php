
<?php

include("conexion.php");

if (isset($_POST['enviar'])){
    if(
        strlen($_POST['precio']) >= 1 &&
        strlen($_POST['descripcion']) >= 1 &&
        strlen($_POST['nombre']) >= 1 
                    ) {
        $precio = trim($_POST['precio']);
        $descripcion = trim($_POST['descripcion']);
        $nombre = trim($_POST['nombre']);
        
        $consulta = "INSERT INTO productos(Precio,DescripcionProducto,Nombre)
            VALUES('$precio','$descripcion','$nombre')";
        
        $resultado=mysqli_query($conexion,$consulta);
        
        if($resultado){
            ?>
                <h2 class="success" >Tu registro se ha completado satisfactoriamente</h2>
            <?php
        } else {
            ?>
                <h2 class="error" >Ocurrio un error</h2>
            <?php
            }
        } else {
        ?>
            <h2 class="error" >Llene los campos de registro</h2>
        <?php
        }   
    }
?>
