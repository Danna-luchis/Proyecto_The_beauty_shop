<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="style.css">
    <link rel="ico" href="Logo.ico">
</head>
<body bgcolor="#ffccaa">
<img src="images/tinalandia Beauty.png" width="15%" align="right">
    <br>
    <br>
    <br>
   <center> <MARQUEE bgcolor="#FF8C74" SCROLLAMOUNT="20" width="80%"  BEHAVIOR=alternate style="font-size:50px" ><font color="#FF238A" style="font-family:cursive;"> Tinalandia Beauty Shop </font></MARQUEE>
   <br>
    <br>
    <br>
    <br>
    <br>
    <br>

<form method="post">


 


<font style="font"><a class="btn" href="frontregistrar.php">Registrar</a><br><br></font>
<a class="btn" href="frontiniciarsesion.php">Iniciar Sesion</a><br><br>
<a class="btn" href="principal.php">Pagina Principal</a><br><br>
<a class="btn" href="nosotros.php">Nosotros</a><br><br>

</form></center>

</html>