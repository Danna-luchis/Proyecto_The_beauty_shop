<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Agregar Registro</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body bgcolor="#ffccaa">

  <form method="post">
  <img src="images/tinalandia Beauty.png" width="15%" align="right"><br><br><br><br><br><br><br><br><br><br><br>
  <center><font color="#9B00FF"><h1>Bienvenido </h1></font>
    <h2><font color="#0068FF">Agregue un Nuevo Servicio </h2>

    <div class="input-wrapper">
        <input type="text" name="precio" placeholder="Precio">
        <img class="input-icon" src="images/name.svg" alt="">
</div>

<div class="input-wrapper">
        <input type="text" name="descripcion" placeholder="Descripcion">
        <img class="input-icon" src="images/name.svg" alt="">
</div>

<div class="input-wrapper">
        <input type="text" name="nombre" placeholder="Nombre">
        <img class="input-icon" src="images/name.svg" alt="">
</div>

<input class type="submit" name="enviar" value="Enviar">
</form>

<?php
        include("insertardatos.php");
?><br><br><br>
<center><a class="btn" href="frontregistros.php">Regresar a tabla</a><br><br>
<a class="btn" href="nosotros.php">Nosotros</a><br><br>
<a class="btn" href="principal.php">Pagina Principal</a><br><br></center>



</div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>