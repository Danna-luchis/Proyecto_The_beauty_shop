<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-Zenh87qX5JnK2JnK2J10vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body bgcolor="#ffccaa">
<img src="images/tinalandia Beauty.png" width="15%" align="right"><br><br><br><br><br><br><br><br><br><br><br>
<center><font color="#9B00FF"><h1>Editar </h1></font>
    <h2><font color="#0068FF">Servicios</h2>

<center><form method="post">

<?php
    include_once('conexion.php');
    $sql="SELECT * FROM productos WHERE idProducto =".$_REQUEST['Id'];
    $resultado= $conexion->query($sql);
    $row= $resultado->fetch_assoc();
?>
  
    <input type="Hidden" class="form-control" name="Id" value="<?php echo $row ['idProducto'];?>">

<div class="mb-3">
    <label class="form-label">Precio</label>
    <input type="text" class="form-control" name="precio" value="<?php echo $row['Precio']; ?>">
</div><br><br>

<div class="mb-3">
    <label class="form-label">Descripcion</label>
    <input type="text" class="form-control" name="descripcion" value="<?php echo $row ['DescripcionProducto'];?>">
</div><br><br><br>


<div class="mb-3">
    <label class="form-label">Nombre</label>
    <input type="text" class="form-control" name="nombre" value="<?php echo $row ['Nombre'];?>">
</div><br><br>

<input class type="submit" name="enviar-editar" value="Enviar">
</form></center>

<?php
        include("backeditarregistros.php");
?>

<a class="btn" href="frontregistros.php">Regresar a tabla</a><br><br>
<a class="btn" href="nosotros.php">Nosotros</a><br><br>
<a class="btn" href="principal.php">Pagina Principal</a><br><br>

    </body>

</html>