
<?php

include("conexion.php");

if (isset($_POST['enviar-editar'])){
    if(
        strlen($_POST['Id']) >= 1 &&
        strlen($_POST['precio']) >= 1 &&
        strlen($_POST['descripcion']) >= 1 &&
        strlen($_POST['nombre']) >= 1 
            ) {

            $id = trim($_POST['Id']);
            $precio = trim($_POST['precio']);
            $descripcion = trim($_POST['descripcion']);
            $nombre = trim($_POST['nombre']);
        
        $consulta = "UPDATE productos SET
            Precio='".$precio."',
            DescripcionProducto='".$descripcion."',
            Nombre='".$nombre."'
            WHERE idProducto= '".$id."'";
            
        if ($resultado=$conexion->query($consulta));
        {
            ?>
                <h2 class="success" >El registro fue editado correctamente</h2>
            <?php
        } 
    }
}
?>
