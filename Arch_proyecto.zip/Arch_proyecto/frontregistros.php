<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-Zenh87qX5JnK2JnK2J10vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body bgcolor="#ffccaa"><img src="images/tinalandia Beauty.png" width="15%" align="right"><br><br><br><br><br><br><br><br><br><br><br><br>
<center><font color="#9B00FF"><h1>Servicios Disponibles</h1></font>
    <h2><font color="#0068FF">Observe</h2>
<br>
    <table class="table" border="2" width="50%" align="center" >
        <thead>
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Precio</th>
                <th scope="col">Descripcion</th>
                <th scope="col">Nombre</th>
            </tr>
        </thead>
        <tbody>
            <?php
            require ("conexion.php");
            $sql=$conexion-> query("SELECT * FROM productos");
            
            while ($resultado = $sql->fetch_assoc()) {
                ?>
                
                    <tr>
                        <th scope="row"><?php echo $resultado['idProducto']?></th>
                        <th scope="row"><?php echo $resultado['Precio']?></th>
                        <th scope="row"><?php echo $resultado['DescripcionProducto']?></th>
                        <th scope="row"><?php echo $resultado['Nombre']?></th>
                        <td>   
                            <a href="fronteditarregistros.php?Id=<?php echo $resultado['idProducto']?>" class="btn btn-warning">Editar</a><br>
                            <a href="backeliminarregistros.php?Id=<?php echo $resultado['idProducto']?>" class="btn btn-warning">Eliminar</a>
                    </td>
                    </tr>
                <?php
                }
            ?>
            
        </tbody>
    </table><br><br><br>

    <a class="btn" href="frontagregarregistro.php">Agregar un Nuevo Servicio</a><br><br>
    <a class="btn" href="nosotros.php">Nosotros</a><br><br>
    <a class="btn" href="principal.php">Pagina Principal</a><br><br>

    </body>



</html>